import { currentAccessUser } from '../../lib/user-access.js';
import { MAIN_CATEGORY_ORDER } from '../../public/category-art.js';

const prefix = 'catalog-subcategory:';
const headers = {'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const json = (data,status=200) => Response.json(data,{status,headers});
const normalize = name => name.normalize('NFC').trim().replace(/\s+/g,' ');
function valid(main,name) {
  return MAIN_CATEGORY_ORDER.includes(main) && typeof name==='string' &&
    name.length>0 && name.length<=60 && !/[>\u0000-\u001f\u007f]/.test(name) &&
    !['tümü','tüm ürünler'].includes(name.toLocaleLowerCase('tr-TR'));
}
export async function onRequestGet({request,env}) {
  if(!await currentAccessUser(request,env))return json({error:'Oturum gerekli.'},401);
  try {
    const {results=[]} = await env.DB.prepare("SELECT value FROM app_meta WHERE key LIKE 'catalog-subcategory:%' ORDER BY key").all();
    const entries=[];
    for(const row of results){
      try{
        const record=JSON.parse(row.value);
        if(valid(record.main,record.name))entries.push(record);
      }catch{}
    }
    entries.sort((a,b)=>a.createdAt.localeCompare(b.createdAt)||a.name.localeCompare(b.name,'tr'));
    return json({entries});
  }catch{return json({error:'Alt kategoriler okunamadı.'},503);}
}
export async function onRequestPost({request,env}) {
  const user=await currentAccessUser(request,env);
  if(user?.role!=='admin')return json({error:'Yönetici yetkisi gerekli.'},403);
  let body;
  try{body=await request.json();}catch{return json({error:'Geçersiz istek.'},400);}
  const main=body?.main;
  const name=typeof body?.name==='string'?normalize(body.name):'';
  if(!valid(main,name))return json({error:'Geçerli bir alt kategori adı girin.'},400);
  try{
    const bytes=new TextEncoder().encode(main+' > '+name.toLocaleLowerCase('tr-TR'));
    const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
    const key=prefix+Array.from(digest,n=>n.toString(16).padStart(2,'0')).join('');
    const record={main,name,createdAt:new Date().toISOString()};
    await env.DB.prepare('INSERT OR IGNORE INTO app_meta(key,value) VALUES(?,?)').bind(key,JSON.stringify(record)).run();
    const saved=await env.DB.prepare('SELECT value FROM app_meta WHERE key=?').bind(key).first();
    if(!saved?.value)throw Error('Missing saved record');
    return json({entry:JSON.parse(saved.value)});
  }catch{return json({error:'Alt kategori kaydedilemedi.'},503);}
}
